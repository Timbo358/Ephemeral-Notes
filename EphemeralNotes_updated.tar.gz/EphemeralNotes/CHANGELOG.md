# Changelog

## 0.1.0 – Initial release

* First MVP implementation of Ephemeral Notes.
* Create and list notes stored locally.
* Notes automatically delete after 24 hours by default.
* Settings screen to choose expiration duration (1 h, 12 h, 24 h, 3 d).
* Periodic cleanup using WorkManager.