plugins {
    // Empty root build configuration. All configuration happens in modules.
}

// Common repositories are defined in settings.gradle.kts via dependencyResolutionManagement.