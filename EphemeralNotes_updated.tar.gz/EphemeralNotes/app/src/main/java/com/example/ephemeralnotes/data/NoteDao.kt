package com.example.ephemeralnotes.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    /**
     * Inserts a new note. Conflicts replace the existing note.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(note: Note)

    /**
     * Returns a flow of notes that are not yet expired at [now]. Notes are ordered by
     * their expiration time ascending.
     */
    @Query("SELECT * FROM notes WHERE expireAt > :nowMillis ORDER BY expireAt ASC")
    fun getActiveNotes(nowMillis: Long): Flow<List<Note>>

    /**
     * Deletes notes whose expireAt is before or equal to [now]. Returns the number of
     * rows removed.
     */
    @Query("DELETE FROM notes WHERE expireAt <= :nowMillis")
    suspend fun deleteExpired(nowMillis: Long): Int

    /**
     * Deletes a note by id.
     */
    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteById(id: Long)
}