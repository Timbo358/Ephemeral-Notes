package com.example.ephemeralnotes

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ephemeralnotes.data.AppDatabase
import com.example.ephemeralnotes.data.Note
import com.example.ephemeralnotes.data.NoteRepository
import com.example.ephemeralnotes.data.SettingsRepository
import com.example.ephemeralnotes.util.computeExpireAt
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel that manages notes and settings. It exposes the list of active notes
 * and default expiration settings, and provides methods to create and delete
 * notes. It schedules cleanups implicitly by exposing the list of active notes
 * based on the current system time.
 */
class NoteViewModel(
    private val noteRepository: NoteRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    // Flow of default duration hours from settings.
    val defaultDurationHours: StateFlow<Int> = settingsRepository.defaultDurationHours
        .stateIn(viewModelScope, SharingStarted.Lazily, 24)

    // Flow of active notes. On each subscription, it queries notes based on System.currentTimeMillis().
    val notes: StateFlow<List<Note>> = noteRepository
        .getActiveNotes(System.currentTimeMillis())
        .map { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun insertNote(text: String, durationHours: Int? = null) {
        val now = System.currentTimeMillis()
        viewModelScope.launch {
            // Use provided duration if available; otherwise default from settings
            val hours = durationHours ?: defaultDurationHours.value
            val note = Note(
                text = text,
                createdAt = now,
                expireAt = computeExpireAt(now, hours)
            )
            noteRepository.insert(note)
        }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch {
            noteRepository.deleteById(id)
        }
    }

    fun setDefaultDurationHours(hours: Int) {
        viewModelScope.launch {
            settingsRepository.setDefaultDurationHours(hours)
        }
    }

    /**
     * Factory for constructing [NoteViewModel] with dependencies that require
     * application context.
     */
    class Factory(private val context: Context) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val database = AppDatabase.getInstance(context)
            val repo = NoteRepository(database.noteDao())
            val settingsRepo = SettingsRepository(context)
            @Suppress("UNCHECKED_CAST")
            return NoteViewModel(repo, settingsRepo) as T
        }
    }
}