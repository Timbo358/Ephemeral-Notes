package com.example.ephemeralnotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ephemeralnotes.ui.EphemeralNotesApp

/**
 * Entry point for the application. Sets up Compose content and passes a
 * ViewModel to the app composable.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: NoteViewModel = viewModel(factory = NoteViewModel.Factory(applicationContext))
            EphemeralNotesApp(viewModel = viewModel)
        }
    }
}