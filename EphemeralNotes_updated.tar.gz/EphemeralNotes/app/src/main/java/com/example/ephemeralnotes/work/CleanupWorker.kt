package com.example.ephemeralnotes.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.ephemeralnotes.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Worker that cleans up expired notes. Scheduled periodically and also run on app
 * startup.
 */
class CleanupWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val database = AppDatabase.getInstance(applicationContext)
        val now = System.currentTimeMillis()
        database.noteDao().deleteExpired(now)
        return@withContext Result.success()
    }
}