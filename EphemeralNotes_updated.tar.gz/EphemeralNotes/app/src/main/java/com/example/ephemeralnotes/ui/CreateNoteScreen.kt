package com.example.ephemeralnotes.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.Flow

/**
 * Screen for creating a new note. Shows a text field and a save/cancel row.
 * The default duration is provided via [defaultDurationHoursFlow] but we defer
 * customizing duration in the MVP and always use the default. Future versions
 * could allow selecting a per‑note expiration.
 */
@Composable
fun CreateNoteScreen(
    onSave: (String, Int?) -> Unit,
    onCancel: () -> Unit,
    defaultDurationHoursFlow: Flow<Int>
) {
    val defaultDuration by defaultDurationHoursFlow.collectAsState(initial = 24)
    val textState: MutableState<TextFieldValue> = remember { mutableStateOf(TextFieldValue()) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        OutlinedTextField(
            value = textState.value,
            onValueChange = { textState.value = it },
            label = { Text(text = "Type a quick note...") },
            modifier = Modifier
                .weight(1f)
                .fillMaxSize()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Button(onClick = { onSave(textState.value.text, defaultDuration) }) {
                Text(text = "Save")
            }
            Button(onClick = onCancel) {
                Text(text = "Cancel")
            }
        }
    }
}