package com.example.ephemeralnotes.util

import java.util.concurrent.TimeUnit

/**
 * Computes the expiration timestamp (in millis) given the creation time and a
 * duration in hours.
 */
fun computeExpireAt(createdAt: Long, durationHours: Int): Long {
    val durationMillis = TimeUnit.HOURS.toMillis(durationHours.toLong())
    return createdAt + durationMillis
}

/**
 * Returns a pair of hours and minutes remaining between now and expireAt.
 * Returns null if the note is already expired.
 */
fun remainingTime(nowMillis: Long, expireAt: Long): Pair<Int, Int>? {
    val diff = expireAt - nowMillis
    if (diff <= 0) return null
    val hours = TimeUnit.MILLISECONDS.toHours(diff)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(diff - TimeUnit.HOURS.toMillis(hours))
    return hours.toInt() to minutes.toInt()
}