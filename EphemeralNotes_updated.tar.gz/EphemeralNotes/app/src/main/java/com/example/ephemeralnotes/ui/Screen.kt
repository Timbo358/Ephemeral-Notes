package com.example.ephemeralnotes.ui

/**
 * Navigation destinations for the app. Each screen has a unique route string.
 */
sealed class Screen(val route: String) {
    object List : Screen("list")
    object Create : Screen("create")
    object Settings : Screen("settings")
}