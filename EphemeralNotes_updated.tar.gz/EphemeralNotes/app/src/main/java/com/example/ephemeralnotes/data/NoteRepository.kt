package com.example.ephemeralnotes.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Repository that wraps the DAO. Exposes suspend functions to insert and delete notes,
 * and a flow of active notes filtered by the current time provider.
 */
class NoteRepository(private val dao: NoteDao) {

    fun getActiveNotes(nowMillis: Long): Flow<List<Note>> = dao.getActiveNotes(nowMillis)

    suspend fun insert(note: Note) = withContext(Dispatchers.IO) {
        dao.insert(note)
    }

    suspend fun deleteExpired(nowMillis: Long) = withContext(Dispatchers.IO) {
        dao.deleteExpired(nowMillis)
    }

    suspend fun deleteById(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteById(id)
    }
}