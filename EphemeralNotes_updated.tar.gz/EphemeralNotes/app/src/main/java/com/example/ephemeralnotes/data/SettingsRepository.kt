package com.example.ephemeralnotes.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private const val PREFERENCES_NAME = "ephemeral_settings"

// Extension to create DataStore
private val Context.dataStore by preferencesDataStore(name = PREFERENCES_NAME)

/**
 * Keys used for storing settings.
 */
object PreferenceKeys {
    val DefaultDuration = intPreferencesKey("default_duration_hours")
}

/**
 * Repository for reading and writing settings. Currently only supports the default
 * expiration duration in hours.
 */
class SettingsRepository(private val context: Context) {
    /**
     * Returns a flow of the default expiration duration in hours. Defaults to 24 hours.
     */
    val defaultDurationHours: Flow<Int> = context.dataStore.data
        .map { preferences: Preferences ->
            preferences[PreferenceKeys.DefaultDuration] ?: 24
        }

    /**
     * Saves the default expiration duration in hours.
     */
    suspend fun setDefaultDurationHours(hours: Int) {
        context.dataStore.edit { preferences ->
            preferences[PreferenceKeys.DefaultDuration] = hours
        }
    }
}