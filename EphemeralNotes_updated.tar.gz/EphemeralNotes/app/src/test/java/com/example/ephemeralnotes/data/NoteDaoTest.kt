package com.example.ephemeralnotes.data

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

/**
 * Basic DAO tests verifying insert and query of active notes.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class NoteDaoTest {
    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private val context = ApplicationProvider.getApplicationContext<android.content.Context>()
    private val db: AppDatabase = Room.inMemoryDatabaseBuilder(
        context, AppDatabase::class.java
    ).allowMainThreadQueries().build()
    private val dao = db.noteDao()

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun insertAndQueryActiveNotes() = runBlocking {
        val now = System.currentTimeMillis()
        val note = Note(text = "Test", createdAt = now, expireAt = now + 60_000)
        dao.insert(note)
        val active = dao.getActiveNotes(now).first()
        assertEquals(1, active.size)
    }
}