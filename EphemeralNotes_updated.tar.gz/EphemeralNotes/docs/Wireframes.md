# Wireframes

These textual wireframes outline the structure of each screen in the MVP.

## Note List Screen

- **Top bar**: Displays the app name (`Ephemeral Notes`) and a settings button.
- **Main content**: A lazy list (vertical) of active notes ordered by expiration. Each row shows up to three lines of the note text and a right‑aligned countdown label (e.g., `3h 21m left`).
- **Empty state**: When there are no notes, displays the message `No active notes` in the center of the screen.
- **Floating action button**: A plus icon at the bottom right that navigates to the Create Note screen.

## Create Note Screen

- **Text field**: Full screen multiline input where the user types the note. A placeholder prompts `Type a quick note...`.
- **Action row**: Save and Cancel buttons at the bottom. In the MVP, Save always uses the default duration from settings.

## Settings Screen

- **Top bar**: Title `Settings` with a back arrow to return to the list.
- **Default expiration**: Presents radio buttons for 1 h, 12 h, 24 h, and 3 d. The current selection reflects the value stored in preferences.
- **Stretch sections**: Hidden until feature flags are enabled. These include `App Lock` and `Support the developer` with tip options.