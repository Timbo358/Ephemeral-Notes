# Architecture

Ephemeral Notes uses a layered architecture that separates data, domain logic, and user interface.

## Layers

- **Data layer**: Contains the Room database, DAO interfaces, DataStore preferences, and repository classes. The database stores `Note` entities with fields for `id`, `text`, `createdAt`, and `expireAt`. The `NoteDao` provides methods to insert notes, query active notes, and remove expired notes. The `SettingsRepository` wraps a preferences DataStore to persist the default expiration duration.

- **Domain layer**: Currently thin; the `NoteRepository` is responsible for mediating access between the DAO and view models, and for running operations on a background dispatcher.

- **UI layer**: Built with Jetpack Compose Material 3. It includes:
  - `MainActivity` that hosts the app and provides a `NoteViewModel` via a custom factory.
  - `NoteViewModel` which exposes flows of active notes and the selected default duration. It also manages inserting and deleting notes and updating preferences.
  - Composables for each screen: list, create, and settings. Navigation is handled with a simple `NavHost`.

- **Background work**: The `CleanupWorker` uses WorkManager to periodically remove expired notes. On first run, `EphemeralNotesApp` schedules this worker to run every six hours.

## Feature flags

Two Boolean BuildConfig fields, `ENABLE_APP_LOCK` and `ENABLE_TIP_JAR`, control stretch features. They are both false in the debug configuration. Enabling them in the release build will surface additional UI elements for biometric lock and tip jar.

## Future work

Stretch features outlined in the specification (biometric app lock, tip jar, export, notifications, widgets, themes) are not implemented in the MVP but can be added by creating new modules or feature flags following the same separation of concerns.