# Privacy Policy

### Ephemeral Notes

**Summary**

Ephemeral Notes stores your notes only on your device. The app does not use accounts and does not transmit any data to a server.

**Data we collect**

We do not collect any personal data. All notes remain on your device’s internal storage.

**Data storage**

Notes are stored in an on‑device database. Each note automatically expires and is deleted after the interval you select (1 h, 12 h, 24 h, or 3 d).

**Permissions**

The MVP of Ephemeral Notes does not request any sensitive permissions. There is no network access or external storage access.

**Changes**

This policy may change in future releases. Updates will be documented in the repository.

**Contact**

For questions or concerns, please open an issue on the GitHub repository.