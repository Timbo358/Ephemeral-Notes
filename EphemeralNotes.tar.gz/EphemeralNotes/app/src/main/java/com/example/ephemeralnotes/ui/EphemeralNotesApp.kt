package com.example.ephemeralnotes.ui

import android.content.Context
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.ui.platform.LocalContext
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.ephemeralnotes.NoteViewModel
import com.example.ephemeralnotes.work.CleanupWorker
import java.util.concurrent.TimeUnit

/**
 * Root composable for the app. Sets up navigation and schedules periodic cleanup.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EphemeralNotesApp(viewModel: NoteViewModel) {
    val navController: NavHostController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    // Schedule periodic cleanup when the app is first composed
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        scheduleCleanupWork(context)
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { androidx.compose.material3.Text(text = "Ephemeral Notes") },
                    colors = TopAppBarDefaults.topAppBarColors()
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { paddingValues ->
            NavHost(
                navController = navController,
                startDestination = Screen.List.route,
                modifier = androidx.compose.ui.Modifier.padding(paddingValues)
            ) {
                composable(Screen.List.route) {
                    NoteListScreen(
                        viewModel = viewModel,
                        onAddNote = { navController.navigate(Screen.Create.route) },
                        onOpenSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }
                composable(Screen.Create.route) {
                    CreateNoteScreen(
                        onSave = { text, durationHours ->
                            viewModel.insertNote(text, durationHours)
                            navController.popBackStack()
                        },
                        onCancel = { navController.popBackStack() },
                        defaultDurationHoursFlow = viewModel.defaultDurationHours
                    )
                }
                composable(Screen.Settings.route) {
                    SettingsScreen(
                        defaultDurationHours = viewModel.defaultDurationHours,
                        onDurationChange = { viewModel.setDefaultDurationHours(it) },
                        onNavigateUp = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}

/**
 * Schedules a periodic cleanup task using WorkManager. Runs every 6 hours.
 */
private fun scheduleCleanupWork(context: Context) {
    val workManager = WorkManager.getInstance(context)
    val request = PeriodicWorkRequestBuilder<CleanupWorker>(6, TimeUnit.HOURS)
        .build()
    workManager.enqueueUniquePeriodicWork(
        "cleanup", ExistingPeriodicWorkPolicy.KEEP, request
    )
}