package com.example.ephemeralnotes.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity representing a simple text note. Each note records when it was created and
 * when it should expire. The expireAt field is computed at insert time based on
 * the user’s chosen expiration duration.
 */
@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long,
    val expireAt: Long
)