package com.example.ephemeralnotes.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.icons.Icons
import androidx.compose.material3.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.StateFlow

/**
 * Settings screen allowing the user to change the default expiration duration.
 */
@Composable
fun SettingsScreen(
    defaultDurationHours: StateFlow<Int>,
    onDurationChange: (Int) -> Unit,
    onNavigateUp: () -> Unit
) {
    val selected by defaultDurationHours.collectAsState()
    Column {
        TopAppBar(
            title = { Text("Settings") },
            navigationIcon = {
                IconButton(onClick = onNavigateUp) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors()
        )
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Default expiration", style = MaterialTheme.typography.titleMedium)
            DurationOption(label = "1 hour", value = 1, selected = selected == 1, onSelect = onDurationChange)
            DurationOption(label = "12 hours", value = 12, selected = selected == 12, onSelect = onDurationChange)
            DurationOption(label = "24 hours", value = 24, selected = selected == 24, onSelect = onDurationChange)
            DurationOption(label = "3 days", value = 72, selected = selected == 72, onSelect = onDurationChange)
            // Tip jar and app lock are hidden behind flags. Their UI will be added in stretch.
        }
    }
}

@Composable
private fun DurationOption(label: String, value: Int, selected: Boolean, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect(value) }
            .padding(vertical = 8.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = { onSelect(value) })
        Text(text = label, modifier = Modifier.padding(start = 8.dp))
    }
}